import tkinter as tk
from tkinter import messagebox

# Store user accounts
accounts = {}

# Current logged-in user
current_user = None


# Create Account
def create_account():
    username = entry_new_user.get()
    password = entry_new_pass.get()

    if username == "" or password == "":
        messagebox.showerror("Error", "All fields are required")
        return

    if username in accounts:
        messagebox.showerror("Error", "User already exists")
        return

    accounts[username] = {
        "password": password,
        "balance": 0,
        "history": []
    }

    messagebox.showinfo("Success", "Account Created Successfully")
    entry_new_user.delete(0, tk.END)
    entry_new_pass.delete(0, tk.END)


# Login
def login():
    global current_user

    username = entry_login_user.get()
    password = entry_login_pass.get()

    if username in accounts and accounts[username]["password"] == password:
        current_user = username
        messagebox.showinfo("Success", f"Welcome {username}")

        login_frame.pack_forget()
        account_frame.pack()

    else:
        messagebox.showerror("Error", "Invalid Username or Password")


# Deposit
def deposit():
    try:
        amount = float(entry_amount.get())

        if amount <= 0:
            raise ValueError

        accounts[current_user]["balance"] += amount
        accounts[current_user]["history"].append(
            f"Deposited ₹{amount}"
        )

        messagebox.showinfo(
            "Success",
            f"₹{amount} Deposited Successfully"
        )

        update_balance()

    except ValueError:
        messagebox.showerror("Error", "Enter a valid amount")


# Withdraw
def withdraw():
    try:
        amount = float(entry_amount.get())

        if amount <= 0:
            raise ValueError

        if amount > accounts[current_user]["balance"]:
            messagebox.showerror(
                "Error",
                "Insufficient Funds"
            )
            return

        accounts[current_user]["balance"] -= amount

        accounts[current_user]["history"].append(
            f"Withdrawn ₹{amount}"
        )

        messagebox.showinfo(
            "Success",
            f"₹{amount} Withdrawn Successfully"
        )

        update_balance()

    except ValueError:
        messagebox.showerror("Error", "Enter a valid amount")


# Update Balance
def update_balance():
    balance_label.config(
        text=f"Balance: ₹{accounts[current_user]['balance']:.2f}"
    )


# Show Transaction History
def show_history():
    history_window = tk.Toplevel(root)
    history_window.title("Transaction History")
    history_window.geometry("300x300")

    tk.Label(
        history_window,
        text="Transaction History",
        font=("Arial", 12, "bold")
    ).pack()

    history_text = tk.Text(history_window)
    history_text.pack(fill=tk.BOTH, expand=True)

    for transaction in accounts[current_user]["history"]:
        history_text.insert(tk.END, transaction + "\n")


# Logout
def logout():
    global current_user

    current_user = None

    account_frame.pack_forget()
    login_frame.pack()

    entry_login_user.delete(0, tk.END)
    entry_login_pass.delete(0, tk.END)


# Main Window
root = tk.Tk()
root.title("Online Banking System")
root.geometry("450x500")


# Create Account Frame
create_frame = tk.LabelFrame(root, text="Create Account")
create_frame.pack(pady=10)

tk.Label(create_frame, text="Username").grid(row=0, column=0)
entry_new_user = tk.Entry(create_frame)
entry_new_user.grid(row=0, column=1)

tk.Label(create_frame, text="Password").grid(row=1, column=0)
entry_new_pass = tk.Entry(create_frame, show="*")
entry_new_pass.grid(row=1, column=1)

tk.Button(
    create_frame,
    text="Create Account",
    command=create_account
).grid(row=2, columnspan=2, pady=5)


# Login Frame
login_frame = tk.LabelFrame(root, text="Login")
login_frame.pack(pady=10)

tk.Label(login_frame, text="Username").grid(row=0, column=0)
entry_login_user = tk.Entry(login_frame)
entry_login_user.grid(row=0, column=1)

tk.Label(login_frame, text="Password").grid(row=1, column=0)
entry_login_pass = tk.Entry(login_frame, show="*")
entry_login_pass.grid(row=1, column=1)

tk.Button(
    login_frame,
    text="Login",
    command=login
).grid(row=2, columnspan=2, pady=5)


# Banking Frame
account_frame = tk.Frame(root)

balance_label = tk.Label(
    account_frame,
    text="Balance: ₹0",
    font=("Arial", 12, "bold")
)
balance_label.pack(pady=10)

entry_amount = tk.Entry(account_frame)
entry_amount.pack(pady=5)

tk.Button(
    account_frame,
    text="Deposit",
    width=20,
    command=deposit
).pack(pady=5)

tk.Button(
    account_frame,
    text="Withdraw",
    width=20,
    command=withdraw
).pack(pady=5)

tk.Button(
    account_frame,
    text="Transaction History",
    width=20,
    command=show_history
).pack(pady=5)

tk.Button(
    account_frame,
    text="Logout",
    width=20,
    command=logout
).pack(pady=5)

root.mainloop()